
function toggleVideo(id) {
  let box = document.getElementById(id);
  box.style.display = box.style.display === "block" ? "none" : "block";
}
